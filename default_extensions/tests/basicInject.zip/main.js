console.log("Hello from aboutbrowser!")

console.log("chrome.runtime:")
console.log("chrome.runtime.id:", chrome.runtime.id);
console.log("chrome.runtime.getManifest:", chrome.runtime.getManifest());
console.log("chrome.runtime.getURL:", chrome.runtime.getURL("/owo"));
